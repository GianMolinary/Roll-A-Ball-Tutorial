﻿using System;
using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.UI;

public class PlayerController : MonoBehaviour {

    public float speed;
    public Text countText;
    public Text scoreText;
    public Text winText;
    public Text LivesText;
    public Text GameOver;

    private Rigidbody rb;
    public static int count;
    private int score;
    public int lives = 3;

    void Start ()
    {
        rb = GetComponent<Rigidbody>();
        count = 0;
        score = 0;
        SetCountText();
        winText.text = "";
    }

    /*private void SetCountText()
    {
        throw new NotImplementedException();
    }*/

    void FixedUpdate()
    {
        float moveHorizontal = Input.GetAxis("Horizontal");
        float moveVertical = Input.GetAxis("Vertical");

        Vector3 movement = new Vector3(moveHorizontal, 0.0f, moveVertical);

        rb.AddForce(movement * speed);

        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }

    
    private void OnTriggerEnter(Collider other)
    {
        if (other.gameObject.CompareTag("Pick Up"))
        {
            other.gameObject.SetActive (false);
            count = count + 1;
            score = score + 1;
            SetAllText();
        }
        else if (other.gameObject.CompareTag("Enemy"))
        {
            other.gameObject.SetActive(false);
            count = count + 1;
            score = score - 1;
            SetAllText();
        }

        else if (other.gameObject.CompareTag("Obstacle"))
        {
            lives = lives - 1;
            if (lives <= 0)
            {
                rb.gameObject.SetActive(false);

                SetGameOver();
            }

            SetLivesText();
        }

        if (count == 12)
        {
            transform.position = new Vector3(75.0f, transform.position.y, 3.0f);
        }

        if (count == 24 && score == 24)
        {
            winText.text = "Fatality";
        }
    }

    private void SetAllText()
    {
        SetScoreText();
        SetCountText();
    }

    void SetScoreText()
    {
        scoreText.text = "Score:" + score.ToString();
    
    }

    void SetCountText ()
    {
        countText.text = "Count!!: " + count.ToString();
    }

    void SetLivesText()
    {
        LivesText.text = "Lives: " + lives.ToString();
    }

    void SetGameOver()
    {
        GameOver.text = "Game Over";

        if (Input.GetKey("escape"))
        {
            Application.Quit();
        }
    }
}